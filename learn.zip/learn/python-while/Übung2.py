count = 0
while count != 5:
    count += 1
    print(count)

count = 0
while count <= 20:
    count += 3
    print(count)

count = 20
while count >= 0:
    count -= 3
    print(count)