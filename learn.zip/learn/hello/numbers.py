print("Erste Zahl")
firstNumber = int(input())
print("zweite Zahl")
secondNumber = int(input())
sum = firstNumber + secondNumber
print("Ergebnis:" + str(sum))