value = '6'
if value =='7':
    print('Der Wert ist 7')
elif value == '8':
    print('Wert ist 8')
else:
    print('Der Wert ist nicht der den wir suchen')
print('Fertig')

if value < '8':
    print('The value is less than 8')
elif value < '7':
    print('The value is less than 7')
else:
    print('The value is greater than 8')