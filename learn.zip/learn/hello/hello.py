#print("Hello World!")
print("Wie heisst du?")
name=input()
print("Hallo "+ name)