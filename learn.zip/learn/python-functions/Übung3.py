import deck
cards = deck.create_deck()

for card in cards:
    print(card)