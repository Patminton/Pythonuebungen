import random as dice
roll = dice.randint(1,10)
print(f'Sie haben {roll} gewürfelt.')