import emoji
message = emoji.emojize('Howdy :sun_with_face:')
print(message)